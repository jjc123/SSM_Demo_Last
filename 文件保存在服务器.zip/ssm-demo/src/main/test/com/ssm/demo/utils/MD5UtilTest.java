package com.ssm.demo.utils;

import org.junit.Test;

import static org.junit.Assert.*;

public class MD5UtilTest {

    //得到MD5加密的内容
    @Test
    public void MD5Encode() {
        System.out.println(MD5Util.MD5Encode("123456", "UTF-8"));
        //e10adc3949ba59abbe56e057f20f883e
    }
}