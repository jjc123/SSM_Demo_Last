package com.ssm.demo.service.impl;

import com.ssm.demo.dao.PictureDao;
import com.ssm.demo.entity.Picture;
import com.ssm.demo.service.PictureService;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

//Service 层代码单元测试主要用来检查业务逻辑是否正常，确认事务配置是否正确，以确保数据库事务正确配置以及业务层逻辑的正确实现。
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration("classpath:applicationContext.xml")
public class PictureServiceImplTest {

    @Autowired
    private PictureService pictureService;

    @Test
    public void queryObject() {
        Picture picture = new Picture();
        picture.setPath("http://localhost:8080/dist/img/logo.jpg");
        picture.setRemark("Service单元测试2");
        //Assert为断言
        Assert.assertTrue(pictureService.save(picture) > 0);
    }
}