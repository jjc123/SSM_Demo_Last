package com.ssm.demo.dao;

import com.ssm.demo.entity.Picture;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

//DAO 层代码单元测试主要用来检查和确认 MyBatis 的配置是否生效以及检查 SQL 语句的写法是否正确；
//更改运行器
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration("classpath:applicationContext.xml")
public class PictureDaoTest {

    @Autowired
    private PictureDao pictureDao;
    @Test
    public void findPictureById() {
        Picture picture1 = pictureDao.findPictureById(1);
        Assert.assertTrue(picture1!=null);
    }
}